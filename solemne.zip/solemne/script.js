import * as d3 from "https://cdn.jsdelivr.net/npm/d3@7/+esm"
import data from './data.json' with {type : 'json'}

const poblationData = [
    {name:"sucidios hombres",population:4812946},
    {name:"sucidiosmujeres",population:1027499},
    {name:"sucidios en Chile",population:1992831},
    
]

d3.select('.bars')
    .selectAll('rect')
    .data(poblationData)
    .join('rect')
    .attr('height', 19)
    .attr('width', function(d){
        return d.population * 10e-6
    })
    .attr('y', function(d, i){
        return i * 20
    })

d3.select('.labels')
    .selectAll('text')
    .data(poblationData)
    .join('text')
    .attr('y', function(d, i){
        return i * 20 + 13
    })
    .text(function(d){
        return d.name
    })

const xScale = d3.scaleLinear()
    .domain([0, d3.max(poblationData, d => d.population)])
    .range([0, 700]);

const yScale = d3.scaleBand()
    .domain(poblationData.map(d => d.name))
    .range([0, 200])
    .padding(0.1);

const xAxis = d3.axisBottom(xScale);
d3.select('.x-axis')
    .attr('transform', 'translate(80, 200)')
    .call(xAxis);

    const yAxis = d3.axisLeft(yScale)
d3.select('.y-axis')
  .attr('transform', 'translate(80,0)') 
  .call(yAxis)